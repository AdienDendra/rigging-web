<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="pingback" href="http://localhost:10010/xmlrpc.php" />
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v18.4.1 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found &bull; Adien Site</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found &bull; Adien Site" />
	<meta property="og:site_name" content="Adien Site" />
	<script type="application/ld+json" class="yoast-schema-graph">{
	    "@context": "https://schema.org",
	    "@graph": [
	        {
	            "@type": [
	                "Person",
	                "Organization"
	            ],
	            "@id": "http://localhost:10010/#/schema/person/3b292850d100219354be60275f739823",
	            "name": "adiendendra",
	            "image": {
	                "@type": "ImageObject",
	                "@id": "http://localhost:10010/#personlogo",
	                "inLanguage": "en-US",
	                "url": "http://www.adiendendra.com/wp-content/uploads/2019/12/foto.png",
	                "contentUrl": "http://www.adiendendra.com/wp-content/uploads/2019/12/foto.png",
	                "width": 1038,
	                "height": 1038,
	                "caption": "adiendendra"
	            },
	            "logo": {
	                "@id": "http://localhost:10010/#personlogo"
	            }
	        },
	        {
	            "@type": "WebSite",
	            "@id": "http://localhost:10010/#website",
	            "url": "http://localhost:10010/",
	            "name": "Adien Site",
	            "description": "Site About Adien Dendra",
	            "publisher": {
	                "@id": "http://localhost:10010/#/schema/person/3b292850d100219354be60275f739823"
	            },
	            "potentialAction": [
	                {
	                    "@type": "SearchAction",
	                    "target": {
	                        "@type": "EntryPoint",
	                        "urlTemplate": "http://localhost:10010/?s={search_term_string}"
	                    },
	                    "query-input": "required name=search_term_string"
	                }
	            ],
	            "inLanguage": "en-US"
	        }
	    ]
	}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.google.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Adien Site &raquo; Feed" href="http://localhost:10010/feed/" />
<link rel="alternate" type="application/rss+xml" title="Adien Site &raquo; Comments Feed" href="http://localhost:10010/comments/feed/" />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id='wp-block-library-inline-css' type='text/css'>
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=wp-block-library-inline-css */
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--primary-color: #124c4c;--wp--preset--color--dark-color: #1c1d1f;--wp--preset--color--warning-color: #eaa36e;--wp--preset--color--success-color: #8fae1b;--wp--preset--color--hot-color: #E41D52;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='contact-form-7-css' href='http://localhost:10010/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.6' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-google-fonts-css' href='https://fonts.googleapis.com/css?family=Hind%3A400%2C100%2C300%2C400%2C600%2C700%7CMontserrat%3A400%2C100%2C300%2C400%2C600%2C700%7CRoboto%3A400%2C100%2C300%2C400%2C600%2C700%7COpen+Sans%3A300%2C400&#038;subset=latin%2Clatin-ext&#038;ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-libs-css' href='http://localhost:10010/wp-content/themes/roneous/assets/css/libs.css?ver=6.9.4' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-theme-styles-css' href='http://localhost:10010/wp-content/uploads/wp-less-cache/roneous-theme-styles.css?ver=1778240775' type='text/css' media='all' />
<link rel='stylesheet' id='roneous-style-css' href='http://localhost:10010/wp-content/themes/roneous/style.css?ver=6.9.4' type='text/css' media='all' />
<script type="text/javascript" src="http://localhost:10010/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="http://localhost:10010/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost:10010/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.4" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<link rel="icon" href="http://localhost:10010/wp-content/uploads/2020/05/cropped-AD-LOGO-kotak-3-png-e1588544734306-32x32.png" sizes="32x32" />
<link rel="icon" href="http://localhost:10010/wp-content/uploads/2020/05/cropped-AD-LOGO-kotak-3-png-e1588544734306-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="http://localhost:10010/wp-content/uploads/2020/05/cropped-AD-LOGO-kotak-3-png-e1588544734306-180x180.png" />
<meta name="msapplication-TileImage" content="http://localhost:10010/wp-content/uploads/2020/05/cropped-AD-LOGO-kotak-3-png-e1588544734306-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			/*
You can add your own CSS here.

Click the help icon above to learn more.
*/

.side-menu.offcanvas-show .nav-bar, .main-container.offcanvas-show { transform: translate3d(-50%,0,0); -webkit-transform: translate3d(-50%,0,0); -moz-transform: translate3d(-50%,0,0);}
.offcanvas-container {right: 0;transform: translate3d(200%,0,0); -webkit-transform: translate3d(200%,0,0); -moz-transform: translate3d(200%,0,0);}
.offcanvas-container.offcanvas-show{transform: translate3d(100%,0,0); -webkit-transform: translate3d(100%,0,0); -moz-transform: translate3d(100%,0,0); }
@media( min-width: 1200px ) { 
.offcanvas-container {width: 380px;} 
.offcanvas-container.offcanvas-show { transform: translate3d(0,0,0); -webkit-transform: translate3d(0,0,0); -moz-transform: translate3d(0,0,0);}
.side-menu.offcanvas-show .nav-bar { transform: translate3d(-380px,0,0); -webkit-transform: translate3d(-380px,0,0); -moz-transform: translate3d(-380px,0,0);}
.main-container.offcanvas-show { transform: translate3d(-360px,0,0); -webkit-transform: translate3d(-360px,0,0); -moz-transform: translate3d(-360px,0,0);}
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 wp-theme-roneous normal-layout wpb-js-composer js-comp-ver-6.6.0 vc_responsive">
			<div class="nav-container">
    <nav>
        	
<div class="nav-utility">
	    	    <div class="module left"><i class="ti-email">&nbsp;</i>
	        <span class="sub">hello@adiendendra.com</span>
	    </div>
    	<div class="module right">
		<ul class="list-inline social-list mb24">
            <li><a href="https://www.linkedin.com/in/adiendendra/" target="_blank"><i class="ti-linkedin"></i></a></li><li><a href="https://twitter.com/AdienDendra" target="_blank"><i class="ti-twitter"></i></a></li><li><a href="https://www.facebook.com/ADPrjcts/" target="_blank"><i class="ti-facebook"></i></a></li>        </ul>
    </div>
</div>        <div class="nav-bar">
            <div class="module left">
                <a href="http://localhost:10010/">
                                        <img class="logo logo-light" alt="Adien Site" src="http://www.adiendendra.com/wp-content/uploads/2017/03/logo-headerwhite.png" />
                    <img class="logo logo-dark" alt="Adien Site" src="http://www.adiendendra.com/wp-content/uploads/2017/03/logo-header-green.png" />
                                    </a>
            </div>
            <div class="module widget-wrap mobile-toggle right visible-sm visible-xs">
                <i class="ti-menu"></i>
            </div>
            <div class="module-group right">
                <div class="module left">
                    <ul id="menu-business-menu" class="menu"><li id="menu-item-3763"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3763"><a href="#home">Home</a><li id="menu-item-3764"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3764"><a href="#demoreel">Portfolio</a><li id="menu-item-3768"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3768"><a href="#skill">Skills</a><li id="menu-item-3765"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3765"><a href="#artwork">Artworks</a><li id="menu-item-3766"  class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3766"><a href="#projects">Projects</a></ul>                </div>
				<div class="module widget-wrap search-widget-wrap left">
    <div class="search">
        <a href="#"><i class="ti-search"></i></a>
        <span class="title">Search Site</span>
    </div>
    <div class="widget-inner">
        <form class="search-form" method="get" id="searchform" action="http://localhost:10010/">
	<input type="text" id="s2" class="mb0" name="s" value="" placeholder="Search on site..." autocomplete="off" />
	<input type="submit" value="" class="btn">
</form>    </div>
</div>            </div>
        </div>
    </nav>
</div>	<div class="main-container"><section class="fullscreen">
    <div class="container vertical-alignment">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1">
                <div class="text-center">
                    <h1 class="behind"><i class="ti-unlink"></i></h1>
                    <h1 class="large"><strong>404</strong>Nothing was found</h1>
                    <div class="search-wrap">
                        <p class="lead">Sorry, but nothing matched your search. Please try again with some different keywords.</p>
<form class="search-form" method="get" id="searchform" action="http://localhost:10010/">
	<input type="text" id="s2" class="mb0" name="s" value="" placeholder="Search on site..." autocomplete="off" />
	<input type="submit" value="" class="btn">
</form>                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
		<footer class="footer-widget bg-graydark p0 ">
    <div class="large-container">
        <div class="row">
        	        </div>
    </div>
        <div class="large-container sub-footer">
        <div class="row">
            <div class="col-sm-6">
                <span class="sub">
                    © 2025 Adien Dendra. All Rights Reserved.                </span>
            </div>
            <div class="col-sm-6 text-right">
                <ul class="list-inline social-list">
                    <li><a href="https://www.linkedin.com/in/adiendendra/" target="_blank"><i class="ti-linkedin"></i></a></li><li><a href="https://twitter.com/AdienDendra" target="_blank"><i class="ti-twitter"></i></a></li><li><a href="https://www.facebook.com/ADPrjcts/" target="_blank"><i class="ti-facebook"></i></a></li>                </ul>
            </div>
        </div>
    </div>
    </footer>					<div class="back-to-top"><i class="ti-angle-up"></i></div>
			</div><!--END: main-container-->
	<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/roneous/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script type="text/javascript" src="http://localhost:10010/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"http://localhost:10010/wp-json/","namespace":"contact-form-7/v1"}};
//# sourceURL=contact-form-7-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost:10010/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.6" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=6Lc3K9YZAAAAAMTBJjujk4qvIa9Hy0uY-MtyxE_8&amp;ver=3.0" id="google-recaptcha-js"></script>
<script type="text/javascript" id="wpcf7-recaptcha-js-extra">
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6Lc3K9YZAAAAAMTBJjujk4qvIa9Hy0uY-MtyxE_8","actions":{"homepage":"homepage","contactform":"contactform"}};
//# sourceURL=wpcf7-recaptcha-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost:10010/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.5.6" id="wpcf7-recaptcha-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/bootstrap.js?ver=6.9.4" id="bootstrap-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-includes/js/masonry.min.js?ver=4.2.2" id="masonry-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.equalheights.min.js?ver=6.9.4" id="equalheights-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.smooth-scroll.min.js?ver=6.9.4" id="smoothscroll-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/owl.carousel.min.js?ver=6.9.4" id="owlcarousel-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/plugins/js_composer/assets/lib/flexslider/jquery.flexslider.min.js?ver=6.6.0" id="flexslider-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.social-share-counter.js?ver=6.9.4" id="social-share-counter-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/flickrPhotoStream.js?ver=6.9.4" id="flickr-photo-stream-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.parallax.js?ver=6.9.4" id="jsparallax-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/waypoint.js?ver=6.9.4" id="waypoint-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.counterup.js?ver=6.9.4" id="counterup-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/lightbox.min.js?ver=6.9.4" id="jslightbox-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.mb.YTPlayer.min.js?ver=6.9.4" id="mb-ytplayer-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.countdown.min.js?ver=6.9.4" id="countdown-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/fluidvids.js?ver=6.9.4" id="fluidvids-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/gmap3.min.js?ver=6.9.4" id="gmap3-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/modernizr.js?ver=6.9.4" id="modernizr-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jquery.throttle.min.js?ver=6.9.4" id="jsthrottle-js"></script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/lib/jQuery.shuffle.min.js?ver=6.9.4" id="jsshuffle-js"></script>
<script type="text/javascript" id="roneous-scripts-js-extra">
/* <![CDATA[ */
var wp_data = {"roneous_ajax_url":"http://localhost:10010/wp-admin/admin-ajax.php","roneous_menu_height":"64","roneous_menu_open":"yes","roneous_permalink":""};
//# sourceURL=roneous-scripts-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost:10010/wp-content/themes/roneous/assets/js/scripts.js?ver=6.9.4" id="roneous-scripts-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"http://localhost:10010/wp-includes/js/wp-emoji-release.min.js?ver=6.9.4"}}
</script>
<script type="module">
/* <![CDATA[ */
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=http://localhost:10010/wp-includes/js/wp-emoji-loader.min.js
/* ]]> */
</script>
</body>
</html>